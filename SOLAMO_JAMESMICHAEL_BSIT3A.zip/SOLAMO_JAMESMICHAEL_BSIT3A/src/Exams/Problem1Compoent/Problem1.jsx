import React from 'react';

const StudentDetails = ({ studentName, course, section }) => {
  return (
    <div>
      <h3>Student Details</h3>
      <p><strong>Name:</strong> {studentName}</p>
      <p><strong>Course:</strong> {course}</p>
      <p><strong>Section:</strong> {section}</p>
    </div>
  );
};

export default StudentDetails;
