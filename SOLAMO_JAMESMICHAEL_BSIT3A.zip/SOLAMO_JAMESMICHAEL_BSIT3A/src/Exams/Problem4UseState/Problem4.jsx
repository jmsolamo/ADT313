import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: '',
    yearlevel: '',
    course: 'BSCS'
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: type === 'radio' ? (checked ? value : prevData[name]) : value
    }));
  };

  return (
    <>
      <form>
        <div style={{ display: 'block' }}>
          Name: <input type='text' name='name' value={formData.name} onChange={handleChange} />
        </div>
        <div style={{ display: 'block' }}>
          <p>Year Level:</p>
          {['First Year', 'Second Year', 'Third Year', 'Fourth Year', 'Fifth Year', 'Irregular'].map(level => (
            <div key={level}>
              <input
                type='radio'
                id={level}
                name='yearlevel'
                value={level}
                checked={formData.yearlevel === level}
                onChange={handleChange}
              />
              <label htmlFor={level}>{level}</label>
              <br />
            </div>
          ))}
        </div>
        <div style={{ display: 'block' }}>
          Course:
          <select name='course' value={formData.course} onChange={handleChange}>
            <option value='BSCS'>BSCS</option>
            <option value='BSIT'>BSIT</option>
            <option value='BSCpE'>BSCpE</option>
            <option value='ACT'>ACT</option>
          </select>
        </div>
      </form>
      <div>
        <pre>{JSON.stringify(formData, null, 2)}</pre>
      </div>
    </>
  );
}
