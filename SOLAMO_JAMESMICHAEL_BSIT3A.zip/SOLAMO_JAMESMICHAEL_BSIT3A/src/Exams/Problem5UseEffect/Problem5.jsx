import React, { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(true);
  const idleTimeoutRef = useRef(null);

  useEffect(() => {
    // Dismiss the loading screen after 3 seconds
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Function to handle user typing
    const handleUserActivity = () => {
      clearTimeout(idleTimeoutRef.current);
      setIsIdle(false);

      // Set user to idle after 5 seconds of inactivity
      idleTimeoutRef.current = setTimeout(() => {
        setIsIdle(true);
      }, 800);
    };

    // Add event listeners for user activity
    document.addEventListener('keydown', handleUserActivity);

    return () => {
      // Clean up event listeners
      document.removeEventListener('keydown', handleUserActivity);
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' />
            <p>User is {isIdle ? 'idle' : 'typing'}...</p>
          </div>
        </>
      )}
    </>
  );
}
