import React, { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [formData, setFormData] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleSave = useCallback(() => {
    setCars((prevCars) => [...prevCars, formData]);
    setFormData({ vin: '', make: '', model: '', year: '', color: '' });
  }, [formData]);

  const handleClear = useCallback(() => {
    setFormData({ vin: '', make: '', model: '', year: '', color: '' });
  }, []);

  const handleEdit = useCallback((car) => {
    setFormData(car);
  }, []);

  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
  }, []);

  const handleUpdate = useCallback(() => {
    setCars((prevCars) => 
      prevCars.map((car) => (car.vin === formData.vin ? formData : car))
    );
    setFormData({ vin: '', make: '', model: '', year: '', color: '' });
  }, [formData]);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN: <input type='text' name='vin' value={formData.vin} onChange={handleInputChange} />
        </div>
        <div style={{ display: 'block' }}>
          Make: <input type='text' name='make' value={formData.make} onChange={handleInputChange} />
        </div>
        <div style={{ display: 'block' }}>
          Model: <input type='text' name='model' value={formData.model} onChange={handleInputChange} />
        </div>
        <div style={{ display: 'block' }}>
          Year: <input type='text' name='year' value={formData.year} onChange={handleInputChange} />
        </div>
        <div style={{ display: 'block' }}>
          Color: <input type='text' name='color' value={formData.color} onChange={handleInputChange} />
        </div>
        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleClear}>Clear</button>
        <button type='button' onClick={handleUpdate}>Update</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(car)}>Edit</button>
                  <button type='button' onClick={() => handleDelete(car.vin)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
