import React, { useContext } from 'react';
import { MovieContext } from '../Problem7';
import './Lists.css'; // Assuming you have a CSS file for styling

export default function Lists() {
  const { movies, setSelectedMovie } = useContext(MovieContext);

  return (
    <div className='table-container'>
      <table style={{ width: '100%' }}>
        <thead>
          <tr>
            <th>Title</th>
            <th>Genre</th>
            <th>Release Date</th>
            <th>Director</th>
            <th>Actor 1</th>
            <th>Actor 2</th>
            <th>Rating</th>
            <th>Box Office</th>
            <th>Duration (Minutes)</th>
            <th>Language</th>
          </tr>
        </thead>
        <tbody style={{ textAlign: 'center' }}>
          {movies.map((movie, index) => (
            <tr
              key={movie.vin}
              className='hover-highlight'
              onClick={() => setSelectedMovie(movie)}
            >
              <td>{movie.title}</td>
              <td>{movie.genre}</td>
              <td>{movie.release_date}</td>
              <td>{movie.director}</td>
              <td>{movie.actor_1}</td>
              <td>{movie.actor_2}</td>
              <td>{movie.rating}</td>
              <td>{movie.box_office}</td>
              <td>{movie.duration_minutes}</td>
              <td>{movie.language}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
